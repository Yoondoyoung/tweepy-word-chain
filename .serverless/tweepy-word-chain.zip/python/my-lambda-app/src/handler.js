module.exports.handler = async (event, context) => {
  console.log('hello world')
  return 'successful invocation'
}
